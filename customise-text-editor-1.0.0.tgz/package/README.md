# Customise Text Editor 🚀

A highly customizable, production-ready Rich Text Editor for React, powered by Tiptap and Lucide Icons. Designed for developers who need full control over their editor's look, feel, and features without the bloat.

## 💎 Features

- **3 Layout Modes**: `top-bar`, `bottom-bar`, and selection-triggered `bubble-only`.
- **Dynamic Theming**: Full control over colors, borders, and radius via a single theme object.
- **Rich Toolbar**: Bold, Italic, Underline, Lists, Links, Blockquotes, Code, and more.
- **Built-in Color Pickers**: Real-time color selection for both text and highlights.
- **Ultra-Lightweight**: Highly optimized modular architecture (every component < 60 lines).
- **Responsive**: Horizontally scrollable toolbar with hidden scrollbars for mobile.
- **Type-Safe**: Full TypeScript support out of the box.

## 🚀 Installation

```bash
npm install customise-text-editor
# or
yarn add customise-text-editor
```

## 💻 Usage

```tsx
import { CustomEditor } from 'customise-text-editor';

function MyEditor() {
  return (
    <CustomEditor
      config={{
        theme: {
          primaryColor: '#3b82f6',
          backgroundColor: '#ffffff',
          textColor: '#1e293b',
          borderRadius: '12px'
        },
        layout: 'top-bar',
        placeholder: 'Start typing...',
        features: ['bold', 'italic', 'underline', 'link', 'highlight', 'undo', 'redo']
      }}
    />
  );
}
```

## 🎨 Theme Configuration

| Property | Description | Default |
| :--- | :--- | :--- |
| `primaryColor` | Brand color for active states & borders | `#3b82f6` |
| `backgroundColor` | Editor and toolbar background | `#ffffff` |
| `textColor` | Main text color | `#0f172a` |
| `borderColor` | Border color for the container | `#e2e8f0` |
| `borderRadius` | Main corner radius | `0.75rem` |

## 🛠️ Props

The `CustomEditor` component accepts a `config` object:

- `layout`: `'top-bar' | 'bottom-bar' | 'bubble-only'`
- `features`: Array of tools to display (e.g., `['bold', 'italic', 'link']`)
- `title`: Optional editor title
- `showTitle`: Toggle title visibility
- `placeholder`: Custom placeholder text
- `width`: Number or string (e.g., `800` or `'100%'`)

## 📄 License

MIT © [Your Name]
